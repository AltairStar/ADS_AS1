package com.company;

public class Main {

    public static void main(String[] args) {
        MyArrayList al = new MyArrayList();

        System.out.println("-------------------------------------------------");
        System.out.println("ArrayList::");

        System.out.println("-------------------------------------------------");

        System.out.println("Inserting elements from 0 to 10 to arraylist");

        for(int i = 0; i <= 10; i++){
            al.add(i, i);
        }

        for(int i = 0; i <= al.getSize(); i++){
            System.out.print(al.get(i) + " ");
        }
        System.out.println();
        System.out.println("Find 5: ");
        System.out.println(al.find(5));


        System.out.println("Remove 5: ");

        al.remove(al.find(5));

        System.out.println("Resulting arraylist:");

        for(int i = 0; i <= al.getSize(); i++){
            System.out.print(al.get(i) + " ");
        }
        System.out.println();

        System.out.println("-------------------------------------------------");
        System.out.println("Linked list::");
        System.out.println("-------------------------------------------------");

        MyLinkedList linkedl = new MyLinkedList();
        System.out.println("Inserting elements from 0 to 10 to linkedList");

        for(int i = 0; i <= 10; i++){
            linkedl.add(i, i);
        }

        linkedl.DisplayAll();

        System.out.println();

        System.out.println("Reversing...");

        linkedl.reverse();

        linkedl.DisplayAll();

        System.out.println();

        System.out.println("Searching for 9..   " +  linkedl.find(9));

        System.out.println("Removing...");
        linkedl.remove(linkedl.find(9));

        System.out.println("Resulting linked list");

        linkedl.DisplayAll();




    }
}
