package com.company;

public class MyArrayList {
    int[] arr;
    int capacity = 5;
    int size;

    public MyArrayList(){
        arr = new int[capacity];
    }

    public int getSize(){
        return this.size;
    }

    public int get(int index){
        return arr[index];
    }

    public void increseBuffer(){
        capacity = (int)(1.5 * capacity);
        int[] secondArray = new int[capacity];
        for(int i = 0; i < size; i++){
            secondArray[i] = arr[i];
        }
        arr = secondArray;
    }

    public void add(int newVal, int in){
        if(arr.length == size){
            increseBuffer();
        }
        for(int i = size; i > in; i--){
            arr[i] = arr[i - 1];
        }
        arr[in] = newVal;
        size++;
    }

    public void remove(int in){
        for(int i = in; i < size - 1; i++){
            arr[i] = arr[i + 1];
        }
        size--;
    }

    public int find(int val){
        for(int i = 0; i < size; i++){
            if(arr[i] == val){
                return i;
            }
        }
        return -1;
    }

    public void reverse(){
        for(int i = 0; i < size / 2; i++){
            // swapping i from left and i from right

            int swap = arr[(size - 1) - i];
            arr[(size - 1) - i] = arr[i];
            arr[i] = swap;
        }
    }
}
