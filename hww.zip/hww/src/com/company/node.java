package com.company;

// class to store node

class node<T> {

    // generic variable to store data
    T data;
    // variable to store pointer to the next node
    node next;
    // constructor, when creating next node is always set as null
    public node(T data) {
        this.data = data;
        next = null;
    }
}

