package com.company;

class MyLinkedList<T> {

    // storing starting node of linked list
    node head;

    MyLinkedList(){
        head = null;
    }

    public void add(int ind, T value){
        if(ind == 0){

            // if we need to insert to the start, we should make him head, old head will next of a new head

            //::swap
            node res = head;
            head = new node(value);
            head.next = res;

        } else {

            // otherwise we should linearly go through all nodes before needed and make a new next for previois of needed node
            int index = 0;
            node nodec = head;

            while(nodec != null){
                if(index == ind - 1){
                    node copy = nodec.next;
                    nodec.next = new node(value);
                    nodec.next.next = copy;
                }
                index++;
                nodec = nodec.next;
            }
        }
    }
    public int find(T keyItem){
        int index = 0;
        node cur = head;


        // we just go linearly throuh all nodes and if we find return index;
        while(cur != null){
            if(cur.data == keyItem){
                return index;
            }
            index++;
            cur = cur.next;
        }

        // if there is not such node
        return -1;
    }
    public void reverse(){

        // in reversing linked list, we change .next to previous node, i created node pre for it.
        // nodec is current node in the start it is head
        node pre = null;
        node nodec = head;
        while(nodec != null){
            node next = nodec.next;
            nodec.next = pre;
            pre = nodec;
            nodec = next;
        }
        head = pre;
    }

    public node remove(int ind){

        // in removing we do the same thing as in adding, if we need to remove from start, go update head to head.nxt,
        if(ind == 0){
            node res = head;
            head = head.next;
            return res;
        } else {

            // otherwise, we go through all nodes previous needed, and update next of previous to .next.next
            int index = 0;
            node nodec = head;
            while(index != (ind - 1)){
                nodec = nodec.next;
                index++;
            }
            node res = nodec.next;
            nodec.next = nodec.next.next;
            return res;
        }
    }
    
    public void DisplayAll(){

        // go through all nodes and output data of every node
        node nodec = head;
        while(nodec != null){
            System.out.print(nodec.data + " ");
            nodec = nodec.next;
        }
    }

}

